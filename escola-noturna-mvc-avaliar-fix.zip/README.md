# Escola Noturna — MVC (Express + EJS)

Projeto base para o TCD (Grupo 14) aplicando **MVC** com **Node.js + Express** e **EJS**.

## 🏃‍♂️ Como rodar

```bash
# Requisitos: Node 18+
npm install
npm start
# abra http://localhost:3000
```

## 📁 Estrutura

```
src/
  server.js          # bootstrap do servidor
  app.js             # configuração do Express
  routes/            # rotas HTTP
  controllers/       # lógica de controle (liga Model <-> View)
  models/            # entidades de domínio
  services/db.js     # persistência simples em arquivo JSON
  views/             # EJS templates (View)
data/db.json         # "banco" local para desenvolvimento
```

## 🔧 Recursos implementados (MVP)

- CRUD de **Alunos**, **Professores** e **Turmas**
- Listagem e criação via formulários
- Associação de aluno -> turma
- Persistência em `data/db.json` (sem banco externo)

> Ideal para apresentação e evolução posterior (ex.: migrar para PostgreSQL).

## 📜 Licença
MIT
