export default class Turma {
  constructor({ id, nome, horario }){
    this.id = id;
    this.nome = nome;      // ex: Inglês A1
    this.horario = horario; // ex: 19:00-21:00
  }
}
