export default class Aluno {
  constructor({ id, nome, email, turmaId, avatar, nota, frequencia }){
    this.id = id;
    this.nome = nome;
    this.email = email;
    this.turmaId = turmaId || null;
    this.avatar = avatar || '/img/avatars/a1.png';
    this.nota = (typeof nota === 'number') ? nota : null;
    this.frequencia = (typeof frequencia === 'number') ? frequencia : 0;
  }
}
