export default class Professor {
  constructor({ id, nome, email, avatar }){
    this.id = id;
    this.nome = nome;
    this.email = email;
    this.avatar = avatar || '/img/avatars/p1.png';
  }
}
