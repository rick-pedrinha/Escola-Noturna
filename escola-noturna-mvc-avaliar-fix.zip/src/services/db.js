import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_PATH = path.join(__dirname, '..', '..', 'data', 'db.json');

function initialData(){
  // turmas padrão (período noturno)
  return {
    alunos: [],
    professores: [],
    turmas: [
      { id: "T-A", nome: "Turma A", horario: "18:00-20:00" },
      { id: "T-B", nome: "Turma B", horario: "19:00-21:00" },
      { id: "T-C", nome: "Turma C", horario: "20:00-22:00" }
    ]
  };
}


function load(){
  if(!fs.existsSync(DB_PATH)){
    const initial = initialData();
    fs.writeFileSync(DB_PATH, JSON.stringify(initial, null, 2));
    return initial;
  }
  const raw = fs.readFileSync(DB_PATH, 'utf-8');
  return JSON.parse(raw || '{"alunos":[],"professores":[],"turmas":[]}');
}

function save(db){
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

export const db = {
  get: () => load(),
  set: (newDb) => save(newDb)
};
