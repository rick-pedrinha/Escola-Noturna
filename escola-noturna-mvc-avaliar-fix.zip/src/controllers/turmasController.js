import { db } from '../services/db.js';
import { v4 as uuid } from 'uuid';
import Turma from '../models/turma.js';

export const list = (req, res) => {
  const data = db.get();
  res.render('turmas/list', { turmas: data.turmas });
};

export const create = (req, res) => {
  const data = db.get();
  const { nome, horario } = req.body;
  const novo = new Turma({ id: uuid(), nome, horario });
  data.turmas.push(novo);
  db.set(data);
  res.redirect('/turmas');
};

export const remove = (req, res) => {
  const data = db.get();
  data.turmas = data.turmas.filter(t => t.id !== req.params.id);
  db.set(data);
  res.redirect('/turmas');
};
