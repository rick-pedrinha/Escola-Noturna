import { db } from '../services/db.js';
import { v4 as uuid } from 'uuid';
import Aluno from '../models/aluno.js';

export const list = (req, res) => {
  const data = db.get();
  const turmas = data.turmas;
  const alunos = data.alunos.map(a => ({
    ...a,
    turmaNome: turmas.find(t => t.id === a.turmaId)?.nome || '-'
  }));
  res.render('alunos/list', { alunos, turmas });
};

export const create = (req, res) => {
  const data = db.get();
  const { nome, email, turmaId } = req.body;
  const idx = Math.floor(Math.random()*10)+1;
  const novo = new Aluno({ id: uuid(), nome, email, turmaId: turmaId || null, avatar: `/img/avatars/a${idx}.png`, nota: null, frequencia: 0 });
  data.alunos.push(novo);
  db.set(data);
  res.redirect('/alunos');
};

export const remove = (req, res) => {
  const data = db.get();
  data.alunos = data.alunos.filter(a => a.id !== req.params.id);
  db.set(data);
  res.redirect('/alunos');
};



export const avaliar = (req, res) => {
  const data = db.get();
  const { id } = req.params;
  const ix = data.alunos.findIndex(a => a.id === id);
  if (ix < 0) return res.redirect('/alunos');

  const aluno = data.alunos[ix];

  // Se o campo vier no body, atualiza; caso contrário, mantém o valor atual
  if (Object.prototype.hasOwnProperty.call(req.body, 'nota')) {
    let nota = parseFloat(req.body.nota);
    if (isNaN(nota)) {
      aluno.nota = null;
    } else {
      if (nota < 0) nota = 0;
      if (nota > 10) nota = 10;
      aluno.nota = nota;
    }
  }
  if (Object.prototype.hasOwnProperty.call(req.body, 'frequencia')) {
    let frequencia = parseFloat(req.body.frequencia);
    if (isNaN(frequencia)) frequencia = aluno.frequencia || 0;
    if (frequencia < 0) frequencia = 0;
    if (frequencia > 100) frequencia = 100;
    aluno.frequencia = frequencia;
  }

  data.alunos[ix] = aluno;
  db.set(data);
  res.redirect('/alunos');
};



export const exportCsv = (req, res) => {
  const data = db.get();
  const linhas = ['id;nome;email;turmaId;nota;frequencia'];
  (data.alunos||[]).forEach(a => {
    linhas.push([a.id,a.nome,a.email,a.turmaId||'', (typeof a.nota==='number'?a.nota:''), a.frequencia||0].join(';'));
  });
  res.setHeader('Content-Type','text/csv; charset=utf-8');
  res.setHeader('Content-Disposition','attachment; filename="alunos.csv"');
  res.send(linhas.join('\n'));
};

export const importCsv = (req, res) => {
  // placeholder: implement if needed
  res.redirect('/alunos');
};
