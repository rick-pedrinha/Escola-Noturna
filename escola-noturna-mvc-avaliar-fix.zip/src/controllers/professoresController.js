import { db } from '../services/db.js';
import { v4 as uuid } from 'uuid';
import Professor from '../models/professor.js';

export const list = (req, res) => {
  const data = db.get();
  res.render('professores/list', { professores: data.professores });
};

export const create = (req, res) => {
  const data = db.get();
  const { nome, email } = req.body;
  const idx = Math.floor(Math.random()*10)+1;
  const novo = new Professor({ id: uuid(), nome, email, avatar: `/img/avatars/p${idx}.png` });
  data.professores.push(novo);
  db.set(data);
  res.redirect('/professores');
};

export const remove = (req, res) => {
  const data = db.get();
  data.professores = data.professores.filter(p => p.id !== req.params.id);
  db.set(data);
  res.redirect('/professores');
};
