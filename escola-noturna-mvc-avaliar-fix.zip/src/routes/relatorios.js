import { Router } from 'express';
import { db } from '../services/db.js';
const r = Router();

r.get('/', (req, res) => {
  const data = db.get();
  const alunos = data.alunos || [];
  const turmas = data.turmas || [];
  // agregações por turma
  const porTurma = turmas.map(t => {
    const xs = alunos.filter(a => a.turmaId === t.id);
    const media = xs.length ? (xs.filter(a => typeof a.nota==='number').reduce((s,a)=>s+a.nota,0) / xs.filter(a => typeof a.nota==='number').length || 1) : 0;
    const freq = xs.length ? (xs.reduce((s,a)=>s+(a.frequencia||0),0)/xs.length) : 0;
    const risco = xs.filter(a => (a.frequencia||0)<75 || (typeof a.nota==='number' && a.nota<6)).length;
    return { turma: t.nome, media: Number.isFinite(media)? Number(media.toFixed(1)) : 0, freq: Math.round(freq), risco, total: xs.length };
  });
  res.render('relatorios/index', { title: 'Relatórios', turmas: porTurma });
});

export default r;
