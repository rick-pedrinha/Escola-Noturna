import multer from 'multer';
import { Router } from 'express';
import * as ctrl from '../controllers/alunosController.js';
const r = Router();
const upload = multer({ dest: 'uploads/' });

r.get('/', ctrl.list);
r.post('/', ctrl.create);
r.post('/:id/delete', ctrl.remove);
r.get('/export.csv', ctrl.exportCsv);
r.post('/:id/avaliar', ctrl.avaliar);

export default r;
