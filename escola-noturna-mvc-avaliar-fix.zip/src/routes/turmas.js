import { Router } from 'express';
import * as ctrl from '../controllers/turmasController.js';
const r = Router();

r.get('/', ctrl.list);
r.post('/', ctrl.create);
r.post('/:id/delete', ctrl.remove);

export default r;
