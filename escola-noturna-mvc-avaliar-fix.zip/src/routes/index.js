import { Router } from 'express';
import alunos from './alunos.js';
import professores from './professores.js';
import turmas from './turmas.js';
import relatorios from './relatorios.js';

const router = Router();
import { db } from '../services/db.js';

router.get('/', (req, res) => {
  const data = db.get();
  const alunos = data.alunos || [];
  const professores = data.professores || [];
  const turmas = data.turmas || [];
  const medias = alunos.filter(a=>typeof a.nota==='number').map(a=>a.nota);
  const mediaGeral = medias.length ? (medias.reduce((s,n)=>s+n,0)/medias.length).toFixed(1) : '-';
  const freqMed = alunos.length ? (alunos.reduce((s,a)=>s+(a.frequencia||0),0)/alunos.length).toFixed(0) : '-';
  const risco = alunos.filter(a=> (a.frequencia||0)<75 || (typeof a.nota==='number' && a.nota<6)).length;
  res.render('home', { title: 'Dashboard', kpis: {totalAlunos: alunos.length, totalProf: professores.length, totalTurmas: turmas.length, mediaGeral, freqMed, risco} });
});
router.use('/alunos', alunos);
router.use('/professores', professores);
router.use('/turmas', turmas);
router.use('/relatorios', relatorios);

export default router;
